package interfacedemo;

public interface IPrintable {

	void print();
}
