package inheritancedemo;

public class Client {
	
	public static void displaydetails(Employee emp)
	{
		System.out.println(emp);
		System.out.println("the total salary---"+emp.computeSalary());
	}
	
	public static void main(String[] args)
	{
		displaydetails(new Manager(1,"king",56000,2000));
		displaydetails(new Salesperson(2, "ernst", 78000, 1000, 0.20));
		
		Manager m1=new Manager(2,"ernst",45000,3000);
		m1.print();
	}

}
