package inheritancedemo;

public class Employee {
	
	private int id;
	private String name;
	protected double salary;
	
	public Employee(int id,String name,double salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	
	@Override()
	public String toString()
	{
		return "the details are-----------------+"
				+ "\n id-"+this.id+
				"\n name-"+this.name+
				"\n salary-"+this.salary;
	}
	
	
	public double computeSalary()
	{
		return this.salary;
	}

}
