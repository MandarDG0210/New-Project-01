package inheritancedemo;

import interfacedemo.IPrintable;

public class Manager  extends Employee implements IPrintable{

	private double foodallowance;
	
	public Manager(int id,String name,double salary,double foodallowance)
	{
		super(id,name,salary);
		this.foodallowance=foodallowance;
		
	}
	
	@Override()
	public String toString()
	{
		return super.toString()+" \n foodall-"+this.foodallowance;
	}
	
	@Override()
	public double computeSalary()
	{
		return this.salary+this.foodallowance;
	}

	public void print() 
	{
		// TODO Auto-generated method stub
		System.out.println("In manager print()");
	}
	
}
