package inheritancedemo;

public class Salesperson extends Employee {
	
	private int nos;
	private double commission;
	
	public Salesperson(int empid,String name,double salary,int nos,double commission)
	{
		super(empid,name,salary);
		this.nos=nos;
		this.commission=commission;
	}

	
	public String toString()
	{
		return super.toString()+"\n nos-"+this.nos+
				"\n commission-"+this.commission;
	}
	

	public double computeSalary()
	{
		return this.salary+(this.nos*this.commission);
	}
	
}

