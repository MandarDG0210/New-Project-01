package customexception;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	try
	{
		Student s1=new Student(1,"king",-90);
		System.out.println(s1);
	}
	catch(CustomException ex)
	{
		System.out.println(ex);
	}

	}

}
