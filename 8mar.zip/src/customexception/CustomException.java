package customexception;


public class CustomException extends Exception {
	
	
	public CustomException(String errmsg)
	{
		super(errmsg);
	}

	@Override
	public String toString()
	{
		return super.getMessage();
	}
}
