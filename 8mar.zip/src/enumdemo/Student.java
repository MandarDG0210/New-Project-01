package enumdemo;

public class Student {
	
	private int rollno;
	private String name;
	private Departments deptname;
	
	public Student(int rollno,String name,Departments deptname)
	{
		this.rollno=rollno;
		this.name=name;
		this.deptname=deptname;
	}
	
	Departments  getDept()
	{
		return this.deptname;
	}
	
	@Override
	public String toString()
	{
		return "rollno-"+this.rollno+
				"\n name-"+this.name+
				"\n Dept-"+this.deptname;
	}

}
