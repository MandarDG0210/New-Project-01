package enumdemo;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student s1=new Student(1,"King",Departments.IT);
		System.out.println(s1);
		
		if(s1.getDept()==Departments.IT)
		{
			System.out.println("you aare eligible for IT ");
		}

	}

}
