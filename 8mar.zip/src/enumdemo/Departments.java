package enumdemo;

public enum Departments {
	
	IT,MECHANICAL,CIVIL

}
