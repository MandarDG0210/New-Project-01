package exceptionhandlingdemo;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Client {
	
	public static int divide(int numerator,int denominator) throws ArithmeticException //provides info to caller function
	{ 
		try
		{
			if(denominator==0)
			{
				throw new ArithmeticException("Denominator is zer-nt allowed");
			}
			int result;
			result=numerator/denominator;
			return result;
		}
		catch(ArithmeticException ex)
		{
			throw ex;	  //throw or rethrow exception		
		}
	}
	public static void main(String args[])
	{
		int numerator,denominator,result;
		Scanner in=new Scanner(System.in);
		try  //business logic and possible exception thrower
		{
			System.out.println("Enter the numerator:");
			numerator=in.nextInt();   //InputMismatch exception
			System.out.println("Enter the denominator:");
			denominator=in.nextInt(); //InputMismatch exception
			result=divide(numerator, denominator);			
			System.out.println("the division is "+result);
		}		
		catch(ArithmeticException ex)  //exceptionhandling logic-exception handler
		{
			System.out.println("denominator cannot ne zero");
			System.out.println(ex.getMessage());
		}
		catch(InputMismatchException ex)
		{
			System.out.println("Invalid number");
			System.out.println(ex.getMessage());
		}
		/*catch(Exception ex) {
			System.out.println("Some other err");
			System.out.println(ex.getMessage());
		}*/
		finally  //mandatory block to execute irrespective of exception
		{
			System.out.println("Program terminated");
		}
		
		
	}

}
