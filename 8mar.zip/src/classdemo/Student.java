package classdemo;

public class Student {
	
	//data abstraction- identify the data for student
	
	private int rollno;
	private String name;
	private float marks;	
	
	public Student() //no-args no-para  default
	{
		this.rollno=100;
		this.name="NA";
		this.marks=0.0f;
	}
	
	public Student(int rollno,String name,float marks) //para constr
	{
		this.rollno=rollno; //current object rollno=para rollno
		this.name=name;
		this.marks=marks;
	}
	
	//function abstraction-identify the function for student
	public void login()
	{
		//logic for marking the attendance
		System.out.println("Student logged in");
	}	
	public void logout()
	{
		//logic for marking the logout time attendance
		System.out.println("Student logged out");
	}
	public void displayDetails()
	{
		//logic for displaying student details
		System.out.println("the details are");
		System.out.println("rollno-"+this.rollno);
		System.out.println("name-"+this.name);
		System.out.println("marks-"+this.marks);
	}
}
