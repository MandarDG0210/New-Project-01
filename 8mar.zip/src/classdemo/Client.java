package classdemo;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//create an object of Student class
		
		//LHS reference=RHS object using new
		
		System.out.println("S1--------------");
		Student s1=new Student();
		//s1 is a reference of type Student hence it can refer to Student type of object
		s1.displayDetails();
		
		System.out.println("s2-------------");
		Student s2=new Student(1,"king",76);
		s2.displayDetails();
		
		
		

	}

}
