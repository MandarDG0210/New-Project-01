package basics2;
import java.util.Scanner;

public class Client1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age; //block of age variable is on stack coz its a local variable
		String name;
		//LHF is reference on stack=RHS is an object on heap
		//create a scanner object to accept input from user
		Scanner input=new Scanner(System.in);
		
		//accept the details
		System.out.println("Enter the name:");
		name=input.next();
		System.out.println("Enter your age:");
		age=input.nextInt();
		
		
		//check the eligibilty of user
		if(age>=18)
		{ 
			System.out.println("Hello " + name + " u cn vote"); //concat the string with variable name
		}
		else
		{
			System.out.println("Hello " + name + " u cnt vote");
		}
		
		input.close(); //close the input stream
	}
	
}
