package anonymousclass;

public class FilterStudentBYMarksLessThan40 implements FilterStudent{

	@Override
	public boolean filter(Student stud) {
		// TODO Auto-generated method stub
		if(stud.getMarks()<40)
		{
			return true;
		}
		return false;
	}

}
