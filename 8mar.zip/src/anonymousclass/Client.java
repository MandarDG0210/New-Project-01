package anonymousclass;

import java.util.Scanner;

public class Client {
	
	public static void main(String[] args)
	{
		Student[] sarr=new Student[5];
		
		sarr[0]=new Student(1,"king",67);
		sarr[1]=new Student(2,"Ersnt",88);
		sarr[2]=new Student(3,"John",35);
		sarr[3]=new Student(4,"Max",89);
		sarr[4]=new Student(5,"Mary",65);
		
//		int id;
//		String name;
//		int marks;
//		Scanner in =new Scanner(System.in);
//		
//		for(int index=0;index<5;index++)
//		{
//			//accept id,name,marks local var
//			//sarr[index]=new Student(id,name,marks);
//		}
		
		System.out.println("Student having marks >70");
	//	StudentUtility.ShowFilteredStudents(sarr, new FilterByMarksGreaterThan70());
		
	/*	StudentUtility.ShowFilteredStudents(sarr, new FilterStudent() {
			
			@Override
			public boolean filter(Student stud) {
				// TODO Auto-generated method stub
				if(stud.getMarks()>70)
				{
					return true;
				}
				return false;
			}
		});*/
		
		StudentUtility.ShowFilteredStudents(sarr, (Student stud)->{
			if(stud.getMarks()>70)
			{
				return true;
			}
			return false;
		});
		
		

		System.out.println("Student having marks <40");
		
	//  StudentUtility.ShowFilteredStudents(sarr, new FilterStudentBYMarksLessThan40());
		
	/*	StudentUtility.ShowFilteredStudents(sarr, new FilterStudent() {
			
			@Override
			public boolean filter(Student stud) {
				// TODO Auto-generated method stub
				if(stud.getMarks()<40)
				{
					return true;
				}
				return false;
			}
		});*/
		
		StudentUtility.ShowFilteredStudents(sarr, (Student stud)->{
			if(stud.getMarks()<40)
			{
				return true;
			}
			return false;
		});
		
		System.out.println("Student having marks between 60 -70");
		/*StudentUtility.ShowFilteredStudents(sarr, new FilterStudent() {
			
			@Override
			public boolean filter(Student stud) {
				// TODO Auto-generated method stub
				if(stud.getMarks()>=60 && stud.getMarks()<=70)
				{
					return true;
				}
				return false;
			}
		});*/
		
		StudentUtility.ShowFilteredStudents(sarr, (Student stud)->{
			if(stud.getMarks()>=60 && stud.getMarks()<=70)
			{
				return true;
			}
			return false;
		});
		
		System.out.println("Student having name starting with M");
		/*StudentUtility.ShowFilteredStudents(sarr, new FilterStudent() {
			
			@Override
			public boolean filter(Student stud) {
				// TODO Auto-generated method stub
				if(stud.getName().startsWith("M"))
				{
					return true;
				}
				return false;
			}
		});*/
		
		StudentUtility.ShowFilteredStudents(sarr, (Student stud)->{
			if(stud.getName().startsWith("M"))
			{
				return true;
			}
			return false;
		});
		
		
	}
	
}
