package anonymousclass;

public interface FilterStudent {

	boolean filter(Student stud);
}
