package anonymousclass;

public class FilterByMarksGreaterThan70 implements FilterStudent {

	@Override
	public boolean filter(Student stud) {
		// TODO Auto-generated method stub

			if(stud.getMarks()>70)
			{
				return true;
			}
			return false;
	}

}
