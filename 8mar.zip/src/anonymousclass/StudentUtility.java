package anonymousclass;

public class StudentUtility {

	
	public static void ShowFilteredStudents(Student[] studlist,FilterStudent filtercondition)
	{
		for(Student s:studlist)
		{
			if(filtercondition.filter(s))
			{
				System.out.println(s);
			}
		}
	}
}
