package anonymousclass;

public class Student {
	
	private int rollno;
	private String name;
	private float marks;	
	
	public Student() //no-args no-para  default
	{
		this.rollno=100;
		this.name="NA";
		this.marks=0.0f;
	}
	
	public Student(int rollno,String name,float marks) //para constr
	{
		this.rollno=rollno; //current object rollno=para rollno
		this.name=name;
		this.marks=marks;
	}
	
	int getRollNo()
	{
		return  this.rollno;
	}
	String getName()
	{
		return this.name;
	}
	float getMarks()
	{
		return this.marks;
	}

	@Override
	public String toString()
	{
		return "Rollno-"+this.rollno+"\n Name-"+this.name+"\n Marks-"+this.marks;
	}
}
