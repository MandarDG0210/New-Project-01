package defaultmethodsinterface;

public class SmartWatch implements ElectronicDevice {

	@Override
	public void ON() {
		// TODO Auto-generated method stub
		System.out.println("Smart Watch ON");
	}

	@Override
	public void OFF() {
		// TODO Auto-generated method stub
		System.out.println("Smart Watch OFF");
	}

}
