package defaultmethodsinterface;

public interface ElectronicDevice {
	
	void ON();
	void OFF();
	
	default void charging()
	{
		System.out.println("Device is getting Charged");
	}

}
