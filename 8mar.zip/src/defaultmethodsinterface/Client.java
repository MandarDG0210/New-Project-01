package defaultmethodsinterface;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Mobile m1=new Mobile();
		m1.charging();
		m1.ON();
		m1.OFF();
		
		SmartWatch sw= new SmartWatch();
		sw.charging();
		sw.ON();
		sw.OFF();

	}

}
