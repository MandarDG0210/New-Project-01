package defaultmethodsinterface;

public class Mobile  implements ElectronicDevice{

	@Override
	public void ON() {
		// TODO Auto-generated method stub
		System.out.println("Mobile ON");
		
	}

	@Override
	public void OFF() {
		// TODO Auto-generated method stub
		System.out.println("Mobile OFF");
	}

}
