package interfaceinheritancedemo;

public interface USBTransfer {

	void transferdataUSB();
	
}
