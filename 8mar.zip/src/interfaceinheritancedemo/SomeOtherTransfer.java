package interfaceinheritancedemo;

public interface SomeOtherTransfer extends USBTransfer, BluetoothTransfer{

	void transferdataSomeOther();
}
