package interfaceinheritancedemo;

public class Test implements SomeOtherTransfer {

	@Override
	public void transferdataUSB() {
		// TODO Auto-generated method stub
		System.out.println("Transferring data through USB deivce");
	}

	@Override
	public void transferdataBT() {
		// TODO Auto-generated method stub
		System.out.println("Transferring data through Blutooth");
		
	}

	@Override
	public void transferdataSomeOther() {
		// TODO Auto-generated method stub
		System.out.println("Transferring data through some other deivce");
	}

}
