package interfaceinheritancedemo;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Test t1=new Test();
		t1.transferdataBT();
		t1.transferdataSomeOther();
		t1.transferdataUSB();

	}

}
