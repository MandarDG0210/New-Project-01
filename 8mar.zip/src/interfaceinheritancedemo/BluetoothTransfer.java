package interfaceinheritancedemo;

public interface BluetoothTransfer {
	
	void transferdataBT();

}
