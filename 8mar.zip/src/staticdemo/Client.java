package staticdemo;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student s1=new Student(1,"john",67);
		System.out.println(s1.toString());
		
		Student s2=new Student(2,"Jim",88);
		System.out.println(s2);
		
		Student.updateUniversity();
		
		System.out.println("After updation------------");
		System.out.println(s1); 
		//by default the toString() is called
		//when an object is given inside the 
		//sysout stmt
		System.out.println(s2);
		

	}

}
