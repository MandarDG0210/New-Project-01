package staticdemo;

public class Student {
	
	private int id;
	private String name;
	private int marks;
	private static String university="Pune";
	
	public Student(int id,String name,int marks) //para constr /default
	{
		this.id=id;
		this.name=name;
		this.marks=marks;			
	}
	
	@Override()  //<--- this is an annotation(it provides a special info abt the method to JVM
	public String toString()
	{
		return "the details are-----"+"\n id-"+ this.id+
				"\n name-"+ this.name+
				"\n marks-"+ this.marks+
				"\n university-"+ Student.university;
	}
	
		
	public static void updateUniversity()
	{
		university="Savitibai Pule Pune University";
	}
	
	public int getMarks()
	{
		return this.marks;
	}

}
