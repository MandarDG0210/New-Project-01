package basics;

import java.util.Scanner;

//accept a number from user and display whether it is even or odd
public class Client2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		Scanner in=new Scanner(System.in);
		
		//accept a number
		System.out.println("Enter the number:");
		num=in.nextInt();
		
		if(num%2==0)
		{
			System.out.println("it is an even number");
		}
		else
		{
			System.out.println("it is an odd numebr");
		}
		

	}

}
