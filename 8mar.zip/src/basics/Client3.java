package basics;

import java.util.Scanner;

public class Client3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr=new int[5];
		Scanner in=new Scanner(System.in);
		for(int index=0;index<arr.length;index++)
		{
			System.out.println("enter the ele:");
			arr[index]=in.nextInt();
		}
		
		for(int element:arr)
		{
			System.out.println(element);
		}
		in.close();
		
		
	}

}
