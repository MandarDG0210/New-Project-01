package abstractdemo2;

public class TwoWheeler extends Vehicle {
	
	private String color;
	private String name;
	
	public TwoWheeler(String color,String name)
	{
		this.color=color;
		this.name=name;
	}

	public void kick()
	{
		System.out.println("two wheeler kick applied");
	}
	
	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("Two wheeler started");
		
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		System.out.println("Two wheeler stopped");
	}

	@Override
	public void brake() {
		// TODO Auto-generated method stub
		System.out.println("Two wheeler brake");
	}

	@Override
	public void accelerate() {
		// TODO Auto-generated method stub
		System.out.println("Two wheeler accelerated");
	}

}
