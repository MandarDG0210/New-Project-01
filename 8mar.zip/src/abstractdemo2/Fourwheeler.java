package abstractdemo2;

public class Fourwheeler extends Vehicle {
	
	private String  soundsystem;
	private String   autogear;
	
	
	
	public Fourwheeler(String soundsystem, String autogear) {
		
		this.soundsystem = soundsystem;
		this.autogear = autogear;
	}
	
	public void soundsystemon()
	{
		System.out.println(this.soundsystem+" is ON to play the song");
	}
	
	
	@Override
	public void start() {
		System.out.println("fourwheeler is started");
		
	}
	@Override
	public void stop() {
		System.out.println("fourwheeler is stop");
		
	}
	@Override
	public void brake() {
		System.out.println("fourwheeler is brake");
		
	}
	@Override
	public void accelerate() {
		System.out.println("fourwheeler is accelarate");
		
	}
	
	
	

}
