package abstractdemo2;

public class Client {
	
	public static void ride(Vehicle vh){
		
		//code to identify the runtine type of vh and if it is Twowheeler then call the kick()
		if(vh.getClass().getName()== TwoWheeler.class.getName())
		{
			
			//highertype=loertype  vehicle=twowheeler  upcasting is done implicitly
			//lowertype=highertype  highertype cannot be directly converted to lower type, i.e downcasting is not performed implicitly
			//we nee to down cast the genric reference to the child type explicitly
			
			TwoWheeler scooter= (TwoWheeler)vh;   
			scooter.kick();
		}
		
		vh.start();
		
		if(vh.getClass().getName()==Fourwheeler.class.getName())
		{
			Fourwheeler car=(Fourwheeler)vh;
			car.soundsystemon();
		}
		vh.accelerate();
		vh.brake();
		vh.stop();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TwoWheeler activa=new TwoWheeler("white","Activa");
		ride(activa);
		
		Fourwheeler ford=new Fourwheeler("Sony", "yes");
		ride(ford);

	}

}
