package abstractdemo2;

public abstract class Vehicle {
	
	public abstract void start();
	public abstract void stop();
	public abstract void brake();
	public abstract void accelerate();
	
	

}
