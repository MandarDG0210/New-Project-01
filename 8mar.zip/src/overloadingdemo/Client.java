package overloadingdemo;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("addition of two doubles -"+MathEngine.add(2.6, 7.4));
		System.out.println("addition of two int -"+MathEngine.add(3, 4));
		System.out.println("addition of two strings-"+MathEngine.add("Hello", "World"));

	}

}
