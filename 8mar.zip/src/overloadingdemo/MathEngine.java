package overloadingdemo;

public class MathEngine {

	public static int add(int n1,int n2)
	{
		return n1+n2;
	}
	public static double add(double n1,double n2)
	{
		return n1+n2;
	}
	public static String add(String str1,String str2)
	{
		return str1+str2;		
	}
}
