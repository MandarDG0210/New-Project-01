package arraylistdemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

import customexception.CustomException;
import customexception.Student;



public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
//			ArrayList<Student> slist=new ArrayList<Student>();
//			
//			slist.add(new Student(1,"King",98));
//			slist.add(new Student(2,"Ernst",78));
//			slist.add(new Student(3,"John",79));
//			slist.add(new Student(4,"Mac",86));
//			
//			for(Student stud:slist)
//			{
//				System.out.println(stud);				
//			}
			
			ArrayList<Student> slist=new ArrayList<Student>();
			int choice; String wish;
			do
			{
			System.out.println("1. Add New Student");
			System.out.println("2. Display All Student");
			System.out.println("3. Display Students having marks>90");
			System.out.println("4. Sort by Marks");
			System.out.println("Enter the choice");
			Scanner in=new Scanner(System.in);
			choice=in.nextInt();
			switch(choice)
			{
			case 1:
			{
				int rollno; float marks; String name;
				System.out.println("Enter the details:");
				rollno=in.nextInt();
				name=in.next();
				marks=in.nextFloat();
				
				slist.add(new Student(rollno,name,marks));
				break;
			}
			case 2:
			{
				System.out.println("All student---------------------------");
				for(Student stud:slist)
				{
					System.out.println(stud);
				}
			}
			break;
			case 3:
			{
				System.out.println("Students having marks >90---------------------------");
				for(Student stud:slist)
				{
					if(stud.getMarks()>90)
					{
						System.out.println(stud);
					}
				}
			}
			break;
			
			case 4:
				System.out.println("Student list is getting sorted based on marks.....");
				Collections.sort(slist,new SortByMarks());
				System.out.println("List sorted based on Marks");
				break;
				default:
					System.out.println("Invalid choice");
			}
			
			System.out.println("Do u want to perform more operations (yes/no):");
			wish=in.next(); //YES
			
			}while(wish.toLowerCase().equals("yes"));
		
			
		}
		catch(CustomException e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
		
	}

}
