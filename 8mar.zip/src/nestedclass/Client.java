package nestedclass;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PhoneNumberValidator.validate("+91-98909890");
	
	}

}
