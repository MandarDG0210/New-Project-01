package nestedclass;


//enclosing class
public class PhoneNumberValidator {
	
	private static String phoneRegex="[^0-9]";
	
	//this funciton will check whether the phoneNumber is valid or not
	//we can have one new class having
	//data-phoneNumber function- checkLength() 
	//enclosing funciton
	public static void validate(String phoneNumber) //phoneNumber will contain special char like +91-97765
	{		
		
		//nested/inner/local class
		class PhoneNumberFormatter
		{
			private String formattedPhoneNumber; //this property will represent the number without the special char
					
			public PhoneNumberFormatter(String  pNumber)  //this parameter is  the number without the special char
			{ 
				//nested class can have the directly access of the properties of enclosing class
				this.formattedPhoneNumber=pNumber.replaceAll(phoneRegex,"");  //+91-97765  this.formatted=9197765
			}
			
			public boolean checkLength()
			{
				//return true if the number is valid else false
				if(this.formattedPhoneNumber.length()==12)
				{
					return true;
				}				
				else
				{
					return false;
				}
			}
			
			public String getFormattedNumber()
			{
				return this.formattedPhoneNumber;
			}
			
			//below function will have  direct access of the parameter of validate funciton-enclosing funciton
			public String getOriginalNumber()
			{
				return phoneNumber;
			}
		}
	
		PhoneNumberFormatter obj=new PhoneNumberFormatter(phoneNumber);
		boolean flag=obj.checkLength();
		System.out.println("Original number-"+ obj.getOriginalNumber());
		System.out.println("Formatted number-"+obj.getFormattedNumber());
		if(flag==true)
		{
			System.out.println("Valid");
		}
		else
		{
			System.out.println("Invalid");
		}
	
	}

}
