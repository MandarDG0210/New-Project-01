package containmentdemo;

import java.time.LocalDate;

public class Adhaardetails {
	
	private String adhaarno;
	private String name;
	private LocalDate dob;
	private Address registeredAddress;
	
	public Adhaardetails(String adhaarno,String name,LocalDate dob,Address registeredAddress)
	{
		this.adhaarno=adhaarno;
		this.name=name;
		this.dob=dob;
		this.registeredAddress=registeredAddress;
	}
	
	@Override()
	public String toString()
	{
		return "Your Adhaar details are------------"+
				"\n adhaar no-"+this.adhaarno+
				"\n name-"+this.name+
				"\n DOB-"+this.dob+
				"\n Address-"+this.registeredAddress;
	}

}
