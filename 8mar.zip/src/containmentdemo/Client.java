package containmentdemo;

import java.time.LocalDate;


public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Courier c1=new Courier("1781","John",new Address("ABC APt","Pune","411018"));
		System.out.println(c1);

		
		Adhaardetails ad1=new Adhaardetails("123412341234", "XYZ", LocalDate.of(1987, 6, 23), 
				new Address("XYZ apt","Mumbai","411012"));
		System.out.println(ad1);
		
	}

}
