package containmentdemo;

//Courier has a delivery address
//delieryAddress is an object of Address class
//containment- Courier is a container and deliveryAddress is
//a contained object
public class Courier {
	
	private String id;
	private String name;
	private Address deliveryAddress; //reference
	
	public Courier(String id,String name,Address deliveryAddress)
	{
		this.id=id;
		this.name=name;
		this.deliveryAddress=deliveryAddress;
	}

	@Override
	public String toString()
	{
		return "The courier details are----"+
				"\n courier id -"+this.id+
				"\n courier name-"+this.name+
				"\n delivery address-"+this.deliveryAddress.toString();
				
	}
}
