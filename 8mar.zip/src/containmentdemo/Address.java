package containmentdemo;

public class Address {

	private String line1;
	private String city;
	private String pincode;
	
	public Address(String line1,String city,String pincode)
	{
		this.line1=line1;
		this.city=city;
		this.pincode=pincode;
	}
	
	@Override
	public String toString()
	{
		return "The address is "+this.line1+
				"\n City-"+this.city+
				"\n pincode-"+this.pincode;
	}
	
}
