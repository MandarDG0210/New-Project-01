package abstractclassdemo;

public abstract  class Shape {
	
	protected double area;
	
	public Shape()
	{
		this.area=0.0;
	}

	public abstract void calculateArea(); 
	//a  function without implementation is abstract method
	//it is manadatory for derived class to override the abstract method
	//we cnnt create an objct of class
	
	@Override
	public String toString()
	{
		return "Area- "+this.area;
	}
}

