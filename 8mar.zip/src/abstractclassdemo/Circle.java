package abstractclassdemo;

import interfacedemo.IPrintable;

public class Circle extends Shape implements IPrintable{

	private static final double pi=3.14;
	private double radius;
	
	public Circle(double radius)
	{
		//super(); this is implicitly calles
		this.radius=radius;
	}
	
	
	public void calculateArea()
	{
		this.area= this.radius*this.radius*pi;
	}
	
	@Override
	public String toString()
	{
		return  "radius- "+this.radius+ super.toString();
	}


	
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("In circle print");
		
	}
	
}

