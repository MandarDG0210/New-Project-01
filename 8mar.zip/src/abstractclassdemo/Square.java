package abstractclassdemo;

public class Square extends Shape {
	
private float side;
	
	public Square(float side)
	{
		//super(); this is implicitly call
		this.side=side;
	}
	
	
	public void calculateArea()
	{
		this.area= this.side*this.side;
	}
	
	@Override
	public String toString()
	{
		return  "side - "+this.side+ super.toString();
	}


}
