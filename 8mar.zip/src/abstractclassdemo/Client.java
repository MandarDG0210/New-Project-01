package abstractclassdemo;

public class Client {
	
	public static void displayArea(Shape sh)
	{
		sh.calculateArea();
		System.out.println(sh);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Circle c1=new Circle(3);
		displayArea(c1);
		c1.print();
		Square s1=new Square(4);
		displayArea(s1);
		
		

		
		
	
		
	}

}
