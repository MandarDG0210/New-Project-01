package arrayofobjectsdemo;
import java.util.Arrays;
import java.util.Collections;

import staticdemo.Student;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student sarr[]=new Student[3];  //array of references
		
	//	Student s1;  can refer only one object
		//Student s1[]; can refere array of objects

		sarr[0]=new Student(1,"John",87);
		sarr[1]=new Student(2,"Jim",98);
		sarr[2]=new Student(3,"King",67);
		
		for(Student stud:sarr)
		{
			System.out.println(stud.toString());
		}
		
		int max=sarr[0].getMarks();
		System.out.println("Highest marks are------");
		for(int index=1;index<sarr.length;index++)
		{
			if(max<sarr[index].getMarks())
			{
				max=sarr[index].getMarks();
			}
			
		}
		
		System.out.println("Max marks are "+max);
	}

}
